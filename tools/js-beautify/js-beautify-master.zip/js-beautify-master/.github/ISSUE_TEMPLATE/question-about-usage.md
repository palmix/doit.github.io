---
name: Question about usage
about: You have a question about how to use the beautifier

---

# **DO NOT FILE USAGE QUESTIONS AS ISSUES**
Review the [README.md](https://github.com/beautify-web/js-beautify/blob/master/README.md).
If that does not help, join us on gitter: https://gitter.im/beautify-web/js-beautify .
